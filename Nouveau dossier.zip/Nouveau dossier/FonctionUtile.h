#ifndef FONCITONUTILE_H_INCLUDED
#define FONCITONUTILE_H_INCLUDED
#include <iostream>
#include <string>

char demandeAouB(std::string a,std::string b,std::string c="",std::string d=""); // verifie si l'utilisateur a bien choisie les valeur propos�e
int demandeInt(int b, int c); //verifie le int appartient a l'intervalle [b,c]


#endif // FONCITONUTILE_H_INCLUDED
