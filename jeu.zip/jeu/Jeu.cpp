#include "Jeu.h"

Jeu::Jeu()
{
    std::string MAP_PATH="JeuCree/Jeu.txt";
    std::string fin ="|||||||||||";
    std::ifstream flux(MAP_PATH.c_str()); //on ouvre en lecture la liste des nom de map et on affiche le nom des map existante.
    if(flux)
    {
        std::string Map;
        std::vector<std::string> vectString;
        while(getline(flux,Map))// on parcours toutes les map existante mais on affiche pas les maps "interdite"
        {
            if(Map=="---------------")
            {
                m_emplacementMap.push_back(vectString);
                vectString.clear();
            }
            else
            {
                vectString.push_back(Map);
            }
        }
        flux.close();
    }
    else{std::cout << "ERREUR: Impossible d'ouvrir en lecture le fichier de jeu cree." << std::endl;}
    this->miniMap();
}

void Jeu::miniMap() // cree un tableau identique que m_emplacementMap avec valeur -1 si il y a rien,0 si il y a une map et plus tard 1 si elle a ete deja visite
{
    std::vector<int> vectInt;
    for(int y=0; y<getTailleY()+2;y++){vectInt.push_back(-1);}
    m_miniMap.push_back(vectInt);
    for(int y=0; y<getTailleY();y++)
    {
        std::vector<int> vectInt;
        vectInt.push_back(-1);
        for(int x=0;x<getTailleX();x++)
        {
            if(m_emplacementMap[y][x].substr(0,6)=="Depart"){vectInt.push_back(1);}
            else if(m_emplacementMap[y][x].substr(0,7)!="       "){vectInt.push_back(0);}
            else (vectInt.push_back(-1));
        }
        vectInt.push_back(-1);
        m_miniMap.push_back(vectInt);
    }
    m_miniMap.push_back(vectInt);
}


int Jeu::getTailleX()
{
   return m_emplacementMap[0].size();
}

int Jeu::getTailleY()
{
    return m_emplacementMap.size();
}

void Jeu::afficherMiniMap()
{
    for(int y=1; y<getTailleY()+1;y++)
    {
        for(int x=1;x<getTailleX()+1;x++)
        {
            if((m_miniMap[y][x]==1 || m_miniMap[y-1][x]==1||m_miniMap[y][x-1]==1||m_miniMap[y+1][x]==1||m_miniMap[y][x+1]==1) && m_miniMap[y][x]!=-1)
            {
                std::cout<<".******.";
            }
            else(std::cout<<".      .");
        }
        std::cout<<std::endl;
    }
}


void Jeu::afficherSchemaJeu()
{
    std::cout<<std::endl<<"***Mini Map***"<<std::endl<<std::endl;
    for(int x=0; x<getTailleX();x++)
    {
        std::cout<<"    "<<x<<"    ";
    }
    std::cout<<std::endl<<std::endl;
    for(int y=0; y<getTailleY();y++)
    {
        for(int x=0;x<getTailleX();x++)
        {
            std::cout<<"."<<(m_emplacementMap[y][x]+"       ").substr(0,7)<<".";
        }
        std::cout<<"   "<<y<<std::endl;
    }
    std::cout<<std::endl<<std::endl;
}
