#include <iostream>
#include "Jeu.h"

using namespace std;

int main()
{
    Jeu j;
    j.afficherSchemaJeu();
    j.afficherMiniMap();
    cout << "Hello world!" << endl;
    return 0;
}
