#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

#include <iostream>
#include <fstream>
#include <vector>
#include <string>


class Jeu
{
private:
    std::vector<std::vector<std::string> > m_emplacementMap;
    std::vector<std::vector<int> > m_miniMap;

public:
    Jeu();

    void miniMap();
    int getTailleY();
    int getTailleX();
    void afficherMiniMap();
    void afficherSchemaJeu();
};

#endif // JEU_H_INCLUDED
