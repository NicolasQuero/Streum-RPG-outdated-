#include <iostream>
#include "creaMap.h"
using namespace std;

void creeUneMap();
void creeUnJeu();

int main()
{
    cout<<endl<<"Bienvenue dans l'outil de creation du jeu" <<endl;
    int i=0;
    do
    {
        cout<<"voulez vous cree une map ou cree un jeu a partir de map deja existante ?" <<endl;
        cout<<"cree un map :(m), cree un jeu:(j) ou quitter le l'outil de creation:(q)" <<endl;
        char jOUm=demandeAouB("j","m","q");
        if(jOUm=='m')
        {
            creeUneMap();
        }
        else if(jOUm=='j')
        {
            creeUnJeu();
        }
        else
        {
            cout<<"Merci d'avoir utiliser l'outil de creation de jeu" <<endl;
            i=1;
        }
    }while(i==0);
    return 0;
}


void creeUnJeu()
{
    cout<< endl << "Bienvenue dans la creation de Jeu" << endl <<endl;
}

void creeUneMap()
{
    cout<< endl << "Bienvenue dans la creation de Map" << endl <<endl;

    creaMap a;  // cree un objet creaMap (cardre de la map de taille Lxl)
    cout<< endl;
    a.afficherMap();
    cout<< endl;
    int i = 0 ;

    a.creaMur(); //permet de cree les mur supplementaire de la salle
    cout<< endl;
    cout<< endl;
    a.afficherMap();

    a.creaChoses("Streumons"); //on cree les monstres
    cout<< endl;
    a.afficherMap();
    cout<< endl<< endl;

    a.creaChoses("Diamants"); //on cree les Diamants
    cout<< endl;
    a.afficherMap();
    cout<< endl<< endl;

    a.creaChoses("Chargeurs"); //on cree les Chargeurs
    cout<< endl;
    a.afficherMap();
    cout<< endl<< endl;

    do
    {
        cout<<"cette map vous convient-elle ?" <<endl<<"il est encore temps de la modifier(ajouter des murs, des Streumons ..."<< endl<<"(oui (o) ou non (n))"<<endl;
        char oOUn=demandeAouB("o","n");
        if (oOUn=='o')
        {
            i=1;
        }
        else
        {
            cout << "voulez vous ajouter des murs ?(m), des Streumons ? (s), des Diamants ?(d), ou des Chargeurs ?(c)";
            char oOUn=demandeAouB("m","s","d","c");
            if(oOUn=='m')
            {
                a.creaMur(); //permet de cree les mur supplementaire de la salle
                cout<< endl;
                cout<< endl;
                a.afficherMap();
            }
            else if (oOUn=='s')
            {
                a.creaChoses("Streumons"); //on cree les monstres
                cout<< endl;
                a.afficherMap();
                cout<< endl<< endl;

            }
            else if (oOUn=='d')
            {
                a.creaChoses("Diamants"); //on cree les Diamants
                cout<< endl;
                a.afficherMap();
                cout<< endl<< endl;

            }
            else
            {
                a.creaChoses("Chargeurs"); //on cree les Chargeurs
                cout<< endl;
                a.afficherMap();
                cout<< endl<< endl;
            }
        }
    }while (i==0);

    a.afficherMap();
    cout<<"felicitation votre map est terminee"<<endl;
    a.enregistrerMap();
}


