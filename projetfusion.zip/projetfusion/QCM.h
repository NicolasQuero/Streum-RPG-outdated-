#ifndef QCM_H_INCLUDED
#define QCM_H_INCLUDED
#include <iostream>
#include "FonctionUtile.h"

int QCMQuestion1();
int QCMQuestion2();
int QCMQuestion3();
int QCMQuestion4();
int QCMQuestion5();

#endif // QCM_H_INCLUDED
