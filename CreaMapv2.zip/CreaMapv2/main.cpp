#include <iostream>
#include "creaMap.h"
using namespace std;


int main()
{
    cout<< endl << "Bienvenue dans la creation de map" << endl <<endl;

    creaMap a;  // cree un objet creaMap (cardre de la map de taille Lxl)
    cout<< endl;
    a.afficherMap();
    cout<< endl;

    a.creaMur(); //permet de cree les mur supplementaire de la salle
    cout<< endl;
    a.afficherMap();
    cout<< endl;

    a.enregistrerMap();


    return 0;
}
