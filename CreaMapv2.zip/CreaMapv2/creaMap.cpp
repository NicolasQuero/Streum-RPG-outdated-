#include "creaMap.h"

creaMap::creaMap(){

    std::cout << "De quelle longueur voulez vous votre Map? (Axe des X)"<< std::endl << "(valeur de 10 a 100)"<<std::endl;
    int longMap;
    longMap=demandeInt(10,100);

    std::cout << "De quelle hauteur voulez vous votre Map? (Axe des Y)" << std::endl << "(valeur de 10 a 100)"<<std::endl; // on cree les deux valeurs qui seront la taille de la map
    int hautMap;
    hautMap=demandeInt(10,100);


    m_longueur=longMap;
    m_hauteur=hautMap;

    std::string creationLigne[hautMap];
    for (int i(0);i<hautMap;i++)
    {
        for (int j(0);j<longMap;j++)
        {
            if(j==0 || i==0 || i==hautMap-1 || j==longMap-1)
            {
                creationLigne[i]+="#";
            }
            else
            {
                creationLigne[i]+=" ";
            }
        }
        mapStrings.push_back(creationLigne[i]);
    }
}

int creaMap::getLongueur()const
{
    return m_longueur;
}

int creaMap::getHauteur()const
{
    return m_hauteur;
}

std::string creaMap::getMapStrings(int i)const
{
    return mapStrings[i];
}

void creaMap::afficherMap()const
{
    for(int i(0);i< this->getHauteur();i++)
    {
        std::cout<<this->getMapStrings(i)<<std::endl;
    }
}



void creaMap::creaMur()//on demande si le joueur veut cree des murs sur la map, puis on les construit.
{
    std::vector<std::string> copieMapStrings=mapStrings;
    std::cout << "voulez vous creer des murs supplementaires dans la salle ? (attention de ne pas vous enfermer)" << std::endl << "(oui (o) ou non (n))"<<std::endl;
    std::string oOUn;
    oOUn=demandeAouB("o","n");
    if (oOUn=="n")
    {
        std::cout << "tres bien, passons a l'etape suivante" << std::endl;
    }
    else
    {
        std::cout << "voulez vous creer des murs horizontaux ou verticaux ?" << std::endl << "(horizontaux (h) ou verticaux(v))"<<std::endl;
        std::string hOUv;
        hOUv=demandeAouB("h","v");
        std::cout << "a quelle position en X voulez vous creer le debut de votre mur ?" << std::endl <<"valeur de 2 a "<< getLongueur()-1 << std::endl;
        int valX = demandeInt(2,getLongueur()-1);
        std::cout << "a quelle position en Y voulez vous creer le debut de votre mur ?" << std::endl <<"valeur de 2 a "<< getHauteur()-1 << std::endl;
        int valY = demandeInt(2,getHauteur()-1);
        std::cout << "de quelle taille voulez vous votre mur ?" << std::endl;
        if (hOUv=="h")
        {
            std::cout <<"valeur de "<<1<<" a "<<getLongueur()-valX<< std::endl;
            int valDist = demandeInt(1,getLongueur()-valX);
            for (int i=0;i<valDist;i++)
            {
                this->modifierValeurMap('#',valX-1+i,valY-1);
            }
        }
        else
        {
            std::cout <<"valeur de "<<1<<" a "<<getHauteur()-valY<< std::endl;
            int valDist = demandeInt(1,getHauteur()-valY);
            for (int i=0;i<valDist;i++)
            {
                this->modifierValeurMap('#',valX-1,valY-1+i);
            }
        }
        this->afficherMap();
        std::cout << "ce mur vous convient-il ?" << std::endl << "(oui (o) ou non (n))"<<std::endl;
        oOUn=demandeAouB("o","n");
        if (oOUn=="n")
        {
            mapStrings=copieMapStrings;
            this->afficherMap();
        }
        this->creaMur();
    }
}

void creaMap::modifierValeurMap(char a, int posX,int posY) // modifie le charactere en X Y par 'a'
{
    this->mapStrings[posY][posX]=a;
}

void creaMap::enregistrerMap() const
{
    const std::string MAP_PATH="Map/test.txt";
    std::ofstream flux(MAP_PATH.c_str());
    if(flux.is_open())
    {
        for(int i(0);i< this->getHauteur();i++)
        {
            flux<<this->getMapStrings(i)<<std::endl;
        }
        flux.close();
    }
    else{std::cout<<"erreur ouverture fichier";}

}



//#########################################
//fonction en dehors de CreaMap::

char demandeAouB(std::string a,std::string b) // verifie si l'utilisateur a bien choisie oui ou non
{
    std::string AouB;
    std::cin.clear();
    std::cin >> AouB;
    while(AouB!=a && AouB!=b )
    {
        std::cout <<"la valeur est incorrect, merci de choisir  entre oui (o) et non (n))"<< std::endl;
        std::cin.clear();
        std::cin.ignore(256,'\n');
        std::cin>> AouB;
    }
    return (AouB[0])  ;
}


int demandeInt(int b, int c) //verifie la selection entre deux valeur b et c
{
    int val;
    std::cin.clear();
    std::cin >> val;
    while (val < b  || val > c || std::cin.fail() )
    {
        std::cout <<"la valeur est incorrect, merci de choisir une valeur entre" <<b<<" et "<<c<< std::endl;
        std::cin.clear();
        std::cin.ignore(256,'\n');
        std::cin>> val;
    }
    return val;
}
